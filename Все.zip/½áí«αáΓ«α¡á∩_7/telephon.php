<?php
$phonebook = array(
    "Костенович" => "123-4567",
    "Петров" => "234-5678",
    "Алефанова" => "345-6789",
    "Николаев" => "456-7890"
);

ksort($phonebook);

echo "Телефонный справочник:<br>";
foreach ($phonebook as $last_name => $phone_number) {
    echo "Фамилия: " . $last_name . ", Телефон: " . $phone_number . "<br>";
}
?>
