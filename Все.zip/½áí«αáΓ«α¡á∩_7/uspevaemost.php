<?php
$gradebook = array(
    array(
        "student_info" => array("group_number" => "10702221", "record_book_number" => "1070222112", "last_name" => "Комисарова", "first_name" => "Алина", "middle_name" => "Львовна"),
        "subjects" => array(
            "Высшая математика" => 5,
            "Программирование" => 5,
            "3D-моделирование" => 5,
            "Тестирование ПО" => 5
        )
    ),
    array(
        "student_info" => array("group_number" => "10611320", "record_book_number" => "1061132009", "last_name" => "Жерко", "first_name" => "Вадим", "middle_name" => "Евгеньевич"),
        "subjects" => array(
            "Высшая математика" => 4,
            "Программирование" => 3,
            "3D-моделирование" => 5,
            "Тестирование ПО" => 4
        )
    ),
    array(
        "student_info" => array("group_number" => "10703219", "record_book_number" => "1070321923", "last_name" => "Куприянов", "first_name" => "Василий", "middle_name" => "Алексеевич"),
        "subjects" => array(
            "Высшая математика" => 3,
            "Программирование" => 5,
            "3D-моделирование" => 4,
            "Тестирование ПО" => 3
        )
    ),
    array(
        "student_info" => array("group_number" => "10200923", "record_book_number" => "1020092320", "last_name" => "Сухолистова", "first_name" => "Ирина", "middle_name" => "Дмитриевна"),
        "subjects" => array(
            "Высшая математика" => 2,
            "Программирование" => 2,
            "3D-моделирование" => 2,
            "Тестирование ПО" => 3
        )
    )
);

foreach ($gradebook as $student) {
    $total_grades = 0;
    $num_subjects = 0;
    echo "Студент: " . $student["student_info"]["last_name"] . " " . $student["student_info"]["first_name"] . " " . $student["student_info"]["middle_name"] . "<br>";
    echo "Группа: " . $student["student_info"]["group_number"] . ", Номер зачетной книжки: " . $student["student_info"]["record_book_number"] . "<br>";
    foreach ($student["subjects"] as $subject => $grade) {
        echo "Предмет: " . $subject . ", Оценка: " . $grade . "<br>";
        $total_grades += $grade;
        $num_subjects++;
    }
    $average_grade = $total_grades / $num_subjects;
    echo "Средний балл: " . $average_grade . "<br>";
    if ($average_grade == 5) {
        echo "Отличник<br><br>";
    } elseif ($average_grade >= 4) {
        echo "Хорошист<br><br>";
    } elseif ($average_grade >= 3) {
        echo "Троечник<br><br>";
    } else {
        echo "Двоечник<br><br>";
    }
}
?>
