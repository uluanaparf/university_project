<?php
// Функция для проверки простого числа
function isPrime($num) {
    if($num < 2) {
        return false;
    }
    for($i = 2; $i <= sqrt($num); $i++) {
        if($num % $i == 0) {
            return false;
        }
    }
    return true;
}

// Функция для нахождения наибольшего и наименьшего простых чисел
function findPrimeNumbers($numbers) {
    $primes = array_filter($numbers, 'isPrime');
    if(count($primes) > 0) {
        return [min($primes), max($primes)];
    } else {
        return [null, null];
    }
}

// Функция для построения треугольника Паскаля
function pascalTriangle($n) {
    $triangle = array();
    for($i = 0; $i < $n; $i++) {
        $triangle[$i] = array();
        $triangle[$i][0] = $triangle[$i][$i] = 1;
        for($j = 1; $j < $i; $j++) {
            $triangle[$i][$j] = $triangle[$i-1][$j-1] + $triangle[$i-1][$j];
        }
    }
    return $triangle;
}

// Функция для возвращения текста приветствия в зависимости от текущего времени
function greeting() {
    $hour = date('H');
    if($hour < 12) {
        return "Доброе утро!";
    } elseif($hour < 18) {
        return "Добрый день!";
    } else {
        return "Добрый вечер!";
    }
}
// Ваши функции здесь

// Проверка функции findPrimeNumbers
$numbers = range(1, 100);
list($min_prime, $max_prime) = findPrimeNumbers($numbers);
echo "Наименьшее простое число: $min_prime<br>";
echo "Наибольшее простое число: $max_prime<br>";

// Проверка функции pascalTriangle
$n = 5;
$triangle = pascalTriangle($n);
echo "Треугольник Паскаля для n = $n:<br>";
foreach ($triangle as $row) {
    echo implode(' ', $row) . "<br>";
}

// Проверка функции greeting
echo greeting();

?>
