<?php
// Загрузка настроек из INI-файла
$settings = parse_ini_file('settings.ini');

// Выбор языка на основе выбора пользователя или настроек по умолчанию
$lang = isset($_GET['lang']) && in_array($_GET['lang'], $settings['languages']) ? $_GET['lang'] : $settings['default_language'];
$translations = parse_ini_file("translations_$lang.ini");

?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $translations['title']; ?></title>
</head>
<body>
    <h1><?php echo $translations['heading']; ?></h1>
    <p><?php echo $translations['paragraph']; ?></p>
    <form>
        <select name="lang" onchange="this.form.submit()">
            <?php foreach ($settings['languages'] as $language): ?>
                <option value="<?php echo $language; ?>" <?php if ($language == $lang) echo 'selected'; ?>><?php echo $language; ?></option>
            <?php endforeach; ?>
        </select>
    </form>
</body>
</html>
