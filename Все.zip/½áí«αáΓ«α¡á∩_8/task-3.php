<?php

$filename = "num.ini";

function sumNumbersFromIniFile($filename) {
    $numbers = parse_ini_file($filename);
    if ($numbers === false) {
        return "Ошибка при чтении файла $filename";
    }
    return array_sum($numbers);
}

// Функция, которая делит все числа из файла на 5
function divideNumbersFromIniFile($filename) {
    $numbers = parse_ini_file($filename);
    if ($numbers === false) {
        return "Ошибка при чтении файла $filename";
    }
    foreach ($numbers as &$number) {
        $number /= 5;
    }
    return $numbers;
}

// Функция, которая перемножает все числа из файла
function multiplyNumbersFromIniFile($filename) {
    $numbers = parse_ini_file($filename);
    if ($numbers === false) {
        return "Ошибка при чтении файла $filename";
    }
    $result = 1;
    foreach ($numbers as $number) {
        $result *= $number;
    }
    return $result;
}

$dividedNumbers = divideNumbersFromIniFile($filename);
if (is_array($dividedNumbers)) {
    echo "Числа из INI-файла, деленные на 5: " . implode(', ', $dividedNumbers) . "<br>";
} else {
    echo $dividedNumbers . "<br>";
}

$product = multiplyNumbersFromIniFile($filename);
if (is_numeric($product)) {
    echo "Произведение чисел из INI-файла: $product<br>";
} else {
    echo $product . "<br>";
}

$sum = sumNumbersFromIniFile($filename);
if (is_numeric($sum)) {
    echo "Сумма чисел из INI-файла: $sum<br>";
} else {
    echo $sum . "<br>";
}
?>
