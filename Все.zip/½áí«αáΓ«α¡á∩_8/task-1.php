<?php
session_start();

function validate_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (!isset($_SESSION["phonebook"])) {
    $_SESSION["phonebook"] = array(
        "Костенович" => "123-4567",
        "Петров" => "234-5678",
        "Алефанова" => "345-6789",
        "Николаев" => "456-7890"
    );
}

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $last_name = validate_input($_POST["last_name"]);
    $phone_number = validate_input($_POST["phone_number"]);

    // Проверка на корректность введенных данных
    if (empty($last_name) || empty($phone_number)) {
        $error_message = "Оба поля должны быть заполнены";
    } else if (!preg_match("/^[а-яА-Я-' ]*$/u",$last_name)) {
        $error_message = "Только русские буквы и пробелы разрешены в фамилии";
    } else if (!preg_match("/^[0-9]*$/",$phone_number)) {
        $error_message = "Только цифры разрешены в номере телефона";
    } else {
        $_SESSION["phonebook"][$last_name] = $phone_number;
        ksort($_SESSION["phonebook"]);
    }
}

echo "Телефонный справочник:<br>";
foreach ($_SESSION["phonebook"] as $last_name => $phone_number) {
    echo "Фамилия: " . $last_name . ", Телефон: " . $phone_number . "<br>";
}
?>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  Фамилия: <input type="text" name="last_name">
  <br><br>
  Телефон: <input type="text" name="phone_number">
  <br><br>
  <input type="submit" name="submit" value="Добавить">
</form>
<script>
    var error_message = "<?php echo $error_message; ?>";
    if (error_message != "") {
        alert(error_message);
    }
</script>
