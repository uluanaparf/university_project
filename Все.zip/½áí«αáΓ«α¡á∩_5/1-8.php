<?php
$year = 1991;
echo "Вывод чисел от 1991 до 2016 с использованием цикла while:<br>";
while ($year <= 2016) {
    echo $year . "<br>";
    $year++;
}
?>
