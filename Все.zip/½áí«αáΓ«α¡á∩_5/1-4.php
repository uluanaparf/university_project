<?php
$val1 = 10;
$val2 = 10;

$result = ($val1 == $val2) ? "Values are equal" : "Values are not equal";

echo "Переменная val1 имеет значение: $val1<br>";
echo "Переменная val2 имеет значение: $val2<br>";
echo "Производится операция сравнения: val1 == val2<br>";
echo "Результат: $result";
?>
