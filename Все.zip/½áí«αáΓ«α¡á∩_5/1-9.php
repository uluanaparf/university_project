<?php
$year = 1991;
echo "Вывод чисел от 1991 до 2016 с использованием цикла do-while:<br>";
do {
    echo $year . "<br>";
    $year++;
} while ($year <= 2016);
?>
