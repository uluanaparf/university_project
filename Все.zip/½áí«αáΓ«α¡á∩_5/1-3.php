<?php
$str1 = "Hello, ";
$str2 = "World!";

$result = $str1 . $str2;

echo "Переменная str1 имеет значение: $str1<br>";
echo "Переменная str2 имеет значение: $str2<br>";
echo "Результат: $result";
?>
