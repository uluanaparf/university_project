<?php
$year = 1991;
echo "Вывод чисел от 1991 до 2016 с использованием цикла while, пропуск годов с 1998 по 2004:<br>";
while ($year <= 2016) {
    if ($year >= 1998 && $year <= 2004) {
        $year++;
        continue;
    }
    echo $year . "<br>";
    $year++;
}
?>
