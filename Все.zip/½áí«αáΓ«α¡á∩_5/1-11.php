<?php
$year = 1991;
echo "Вывод чисел от 1991 до 2016 с использованием цикла while, прерывание на 2008 году:<br>";
while ($year <= 2016) {
    if ($year == 2008) {
        break;
    }
    echo $year . "<br>";
    $year++;
}
?>
