<?php
$array = array(
    "Name" => "John Doe",
    "Address" => "123 Main St",
    "Phone" => "123-456-7890",
    "Mail" => "johndoe@example.com"
);

foreach ($array as $key => $value) {
    echo $key . ": " . $value . "<br>";
}
?>
