<?php
$names = array("John", "Bill", "Sam", "Milana");
$name = $names[array_rand($names)];

echo "Выбранное имя: $name<br>";

switch ($name) {
    case "John":
        echo "Привет, John!<br>";
        break;
    case "Bill":
        echo "Привет, Bill!<br>";
        break;
    case "Sam":
        echo "Привет, Sam!<br>";
        break;
    default:
        echo "Приветствую Незнакомец!<br>";
}
?>
