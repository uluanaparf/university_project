<?php
$num1 = 10;
$num2 = 20;

$result = $num1 + $num2;

echo "Переменная num1 имеет значение: $num1<br>";
echo "Переменная num2 имеет значение: $num2<br>";
echo "Производится операция сложения: num1 + num2<br>";
echo "Результат: $result";
?>
