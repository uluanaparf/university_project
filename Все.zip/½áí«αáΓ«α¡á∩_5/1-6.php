<?php
$array = range(1, 100);

foreach ($array as $value) {
    if ($value % 13 != 0) {
        echo $value . "<br>";
    }
}
?>
