<?php
$var1 = 5;
$var2 = "Hello, World!";
$var3 = 1.234;
$var4 = array(1, 2, 3);
$var5 = TRUE;

echo "Переменная var1 имеет значение: $var1 и тип: " . gettype($var1) . "<br>";
echo "Переменная var2 имеет значение: $var2 и тип: " . gettype($var2) . "<br>";
echo "Переменная var3 имеет значение: $var3 и тип: " . gettype($var3) . "<br>";
echo "Переменная var4 имеет значение: ";
print_r($var4);
echo " и тип: " . gettype($var4) . "<br>";
echo "Переменная var5 имеет значение: $var5 и тип: " . gettype($var5) . "<br>";
?>
