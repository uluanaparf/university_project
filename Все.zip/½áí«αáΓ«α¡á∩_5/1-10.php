<?php
echo "Вывод чисел от 1991 до 2016 с использованием цикла for:<br>";
for ($year = 1991; $year <= 2016; $year++) {
    echo $year . "<br>";
}
?>
