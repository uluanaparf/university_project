<?php
$array = array("html", "css", "php", "js");
$str = implode(", ", $array);
echo "Массив: ";
foreach ($array as $value) {
    echo $value . " ";
}
echo "<br>Строка: '$str'";
?>
