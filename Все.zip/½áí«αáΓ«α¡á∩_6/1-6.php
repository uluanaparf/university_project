<?php
$str = "1234567890";
$array = str_split($str, 2);
echo "Исходная строка: '$str'<br>";
echo "Массив:<br>";
foreach ($array as $value) {
    echo $value . " ";
}
?>
