<?php
echo "<pre>";
echo "Пирамида:<br>";
for ($i = 1; $i <= 7; $i++) {
    echo str_repeat(' ', 7 - $i) . str_repeat('#', 2 * $i - 1) . "\n";
}
echo "</pre>";
?>
