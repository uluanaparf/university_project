<?php
$password = "secret";
echo "Пароль: $password<br>";
if (strlen($password) > 5 && strlen($password) < 10) {
    echo "Пароль подходит";
} else {
    echo "Нужно придумать другой пароль";
}
?>
