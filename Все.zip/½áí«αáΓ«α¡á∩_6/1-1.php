<?php
$str = "london is the capital of great britain";
$str = ucwords($str);
echo "Исходная строка: 'london is the capital of great britain'<br>";
echo "Преобразованная строка: '$str'";
?>
