<?php
$str = "html, <b>php</b>, js";
echo "Строка 'как есть':<br>";
echo htmlspecialchars($str);
?>
