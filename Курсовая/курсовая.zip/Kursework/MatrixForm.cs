﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Kursework
{
    public partial class MatrixForm : Form
    { 
        private DataGridView dataGridView;
    
        public MatrixForm(int row, int colums)
        {
            InitializeComponent();
            dataGridView = new DataGridView();
            dataGridView.Dock = DockStyle.Fill;
            Controls.Add(dataGridView);

            // Создание и отображение матрицы.
            CreateAndDisplayMatrix(row, colums);
            
        }


        private void CreateAndDisplayMatrix(int rows, int columns)
        {
            // Создание DataTable для хранения данных матрицы.
            var dataTable = new System.Data.DataTable();

            // Добавление столбцов в DataTable.
            for (int i = 0; i < columns; i++)
            {
                dataTable.Columns.Add($"Column{i + 1}", typeof(int));
            }

            // Добавление строк в DataTable.
            for (int i = 0; i < rows; i++)
            {
                dataTable.Rows.Add();
            }

            // Назначение DataTable элементу DataGridView.
            dataGridView.DataSource = dataTable;
        }
        private void ReadExcelButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
            openFileDialog.Title = "Выберите файл Excel";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                // Чтение данных из Excel файла.
                DataTable dataTable = ReadDataFromExcel(filePath);

                // Проверка соответствия размеров матрицы и таблицы.
                if (dataTable.Rows.Count == dataGridView.Rows.Count &&
                    dataTable.Columns.Count == dataGridView.Columns.Count)
                {
                    // Запись данных в таблицу DataGridView.
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        for (int j = 0; j < dataTable.Columns.Count; j++)
                        {
                            dataGridView.Rows[i].Cells[j].Value = dataTable.Rows[i][j];
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Размеры матрицы в файле Excel не соответствуют размерам таблицы.");
                }
            }
        }

        private DataTable ReadDataFromExcel(string filePath)
        {
            DataTable dataTable = new DataTable();

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workbook = excelApp.Workbooks.Open(filePath);
            Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets[1];

            int rowCount = worksheet.UsedRange.Rows.Count;
            int colCount = worksheet.UsedRange.Columns.Count;

            for (int i = 1; i <= rowCount; i++)
            {
                if (i == 1)
                {
                    for (int j = 1; j <= colCount; j++)
                    {
                        dataTable.Columns.Add("Column" + j, typeof(int));
                    }
                }

                DataRow row = dataTable.NewRow();
                for (int j = 1; j <= colCount; j++)
                {
                    row[j - 1] = worksheet.Cells[i, j].Value;
                }
                dataTable.Rows.Add(row);
            }

            workbook.Close(false);
            excelApp.Quit();

            return dataTable;
        }
    }
}
